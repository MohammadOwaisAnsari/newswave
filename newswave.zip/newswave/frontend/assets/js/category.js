// assets/js/category.js

document.addEventListener('DOMContentLoaded', () => {
    // Fetch category news
    const urlParams = new URLSearchParams(window.location.search);
    const categoryId = urlParams.get('id');
    fetchCategoryNews(categoryId);
});

function fetchCategoryNews(categoryId) {
    fetch(`https://api.example.com/categories/${categoryId}/news`)  // Replace with your category API endpoint
        .then(response => response.json())
        .then(data => {
            const newsContainer = document.querySelector('.news-container');
            newsContainer.innerHTML = data.articles.map(article => `
                <div class="news-card">
                    <h2><a href="article.html?id=${article.id}">${article.title}</a></h2>
                    <p>${article.summary}</p>
                    <p><a href="article.html?id=${article.id}">Read more</a></p>
                </div>
            `).join('');
        })
        .catch(error => console.error('Error fetching category news:', error));
}
