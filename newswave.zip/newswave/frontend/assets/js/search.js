// assets/js/search.js

document.addEventListener('DOMContentLoaded', () => {
    const searchForm = document.getElementById('search-form');
    if (searchForm) {
        searchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const query = document.getElementById('search-query').value;
            searchNews(query);
        });
    }
});

function searchNews(query) {
    fetch(`https://api.example.com/search?q=${query}`)  // Replace with your search API endpoint
        .then(response => response.json())
        .then(data => {
            const resultsContainer = document.getElementById('search-results');
            resultsContainer.innerHTML = data.articles.map(article => `
                <div class="news-card">
                    <h2><a href="article.html?id=${article.id}">${article.title}</a></h2>
                    <p>${article.summary}</p>
                    <p><a href="article.html?id=${article.id}">Read more</a></p>
                </div>
            `).join('');
        })
        .catch(error => console.error('Error searching news:', error));
}
