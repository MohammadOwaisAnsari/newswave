// assets/js/profile.js

document.addEventListener('DOMContentLoaded', () => {
    // Handle profile form submission
    const profileForm = document.getElementById('profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', (e) => {
            e.preventDefault();
            updateProfile();
        });
    }
});

function updateProfile() {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const preferences = document.getElementById('preferences').value;

    fetch('https://api.example.com/profile', {  // Replace with your profile API endpoint
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ name, email, preferences })
    })
        .then(response => response.json())
        .then(data => {
            alert('Profile updated successfully');
        })
        .catch(error => console.error('Error updating profile:', error));
}
