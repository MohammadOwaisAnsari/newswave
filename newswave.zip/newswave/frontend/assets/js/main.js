// assets/js/main.js

document.addEventListener('DOMContentLoaded', () => {
    // Common code can go here, if needed.
});

// Fetch Featured News
function fetchFeaturedNews() {
    fetch('http://localhost:8080/api/news/featured')
        .then(response => response.json())
        .then(data => {
            displayFeaturedNews(data);
        })
        .catch(error => console.error('Error:', error));
}

// Display Featured News
function displayFeaturedNews(news) {
    const newsContainer = document.getElementById('featured-news');
    newsContainer.innerHTML = news.map(item => `
        <div class="news-item">
            <h2>${item.title}</h2>
            <p>${item.description}</p>
        </div>
    `).join('');
}

// Fetch News by Category
function fetchNewsByCategory(category) {
    fetch(`http://localhost:8080/api/news?category=${category}`)
        .then(response => response.json())
        .then(data => {
            displayNews(data);
        })
        .catch(error => console.error('Error:', error));
}

// Display News
function displayNews(news) {
    const newsContainer = document.getElementById('news-container');
    newsContainer.innerHTML = news.map(item => `
        <div class="news-item">
            <h2>${item.title}</h2>
            <p>${item.description}</p>
        </div>
    `).join('');
}

// Search News
function searchNews(query) {
    fetch(`http://localhost:8080/api/news/search?q=${query}`)
        .then(response => response.json())
        .then(data => {
            displaySearchResults(data);
        })
        .catch(error => console.error('Error:', error));
}

// Display Search Results
function displaySearchResults(results) {
    const searchResultsContainer = document.getElementById('search-results');
    searchResultsContainer.innerHTML = results.map(item => `
        <div class="news-item">
            <h2>${item.title}</h2>
            <p>${item.description}</p>
        </div>
    `).join('');
}

// Example usage
document.addEventListener('DOMContentLoaded', function() {
    fetchFeaturedNews(); // Load featured news on page load
});
