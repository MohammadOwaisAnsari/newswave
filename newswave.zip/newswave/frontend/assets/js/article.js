// assets/js/article.js

document.addEventListener('DOMContentLoaded', () => {
    // Fetch article content based on ID
    const urlParams = new URLSearchParams(window.location.search);
    const articleId = urlParams.get('id');
    fetchArticle(articleId);
});

function fetchArticle(id) {
    fetch(`https://api.example.com/articles/${id}`)  // Replace with your article API endpoint
        .then(response => response.json())
        .then(data => {
            const articleDetail = document.getElementById('article-detail');
            articleDetail.innerHTML = `
                <h1>${data.title}</h1>
                <p><em>Published on: ${new Date(data.publishedAt).toLocaleDateString()}</em></p>
                <p>${data.content}</p>
            `;
        })
        .catch(error => console.error('Error fetching article:', error));
}
