// assets/js/homepage.js

document.addEventListener('DOMContentLoaded', () => {
    fetchNews();
});

function fetchNews() {
    fetch('https://api.example.com/news')  // Replace with your news API endpoint
        .then(response => response.json())
        .then(data => {
            const newsContainer = document.querySelector('#trending-news .news-container');
            newsContainer.innerHTML = data.articles.map(article => `
                <div class="news-card">
                    <h2><a href="article.html?id=${article.id}">${article.title}</a></h2>
                    <p>${article.summary}</p>
                    <p><a href="article.html?id=${article.id}">Read more</a></p>
                </div>
            `).join('');
        })
        .catch(error => console.error('Error fetching news:', error));
}
