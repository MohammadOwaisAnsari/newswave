package com.news.newswave;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NewswaveApplicationTests {

	@Test
	void contextLoads() {
	}

}
