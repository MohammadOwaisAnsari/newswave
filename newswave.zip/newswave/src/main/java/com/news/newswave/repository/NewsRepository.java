package com.news.newswave.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.news.newswave.model.NewsArticle;

@Repository
public interface NewsRepository extends JpaRepository<NewsArticle, Long> {
    List<NewsArticle> findByCategoryId(Long categoryId);
    List<NewsArticle> findByTitleContainingIgnoreCase(String query);

     // New method to find trending news
    @Query("SELECT n FROM NewsArticle n WHERE n.trending = true")
    List<NewsArticle> findTrendingNews();
}
