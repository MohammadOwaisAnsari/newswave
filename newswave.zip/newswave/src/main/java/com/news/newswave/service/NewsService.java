package com.news.newswave.service;

import com.news.newswave.model.NewsArticle;
import java.util.List;

public interface NewsService {
    List<NewsArticle> getTrendingNews();
    List<NewsArticle> getNewsByCategory(Long categoryId);
    NewsArticle getNewsById(Long id);
}
