package com.news.newswave.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.news.newswave.model.NewsArticle;
import com.news.newswave.repository.NewsRepository;

@Service
public class SearchServiceImpl implements SearchService {

    @Autowired
    private NewsRepository newsRepository;

    @Override
    public List<NewsArticle> searchNews(String query) {
        // Logic for searching news based on query
        return newsRepository.findByTitleContainingIgnoreCase(query);
    }
}
