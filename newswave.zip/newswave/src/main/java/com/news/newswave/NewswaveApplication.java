package com.news.newswave;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewswaveApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewswaveApplication.class, args);
	}

}
