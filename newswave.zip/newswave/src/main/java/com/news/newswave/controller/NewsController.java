package com.news.newswave.controller;

import com.news.newswave.model.NewsArticle;
import com.news.newswave.service.NewsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/news")
public class NewsController {

    @Autowired
    private NewsService newsService;

    @GetMapping("/trending")
    public ResponseEntity<List<NewsArticle>> getTrendingNews() {
        return ResponseEntity.ok(newsService.getTrendingNews());
    }

    @GetMapping("/category/{categoryId}")
    public ResponseEntity<List<NewsArticle>> getNewsByCategory(@PathVariable Long categoryId) {
        return ResponseEntity.ok(newsService.getNewsByCategory(categoryId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<NewsArticle> getNewsById(@PathVariable Long id) {
        return ResponseEntity.ok(newsService.getNewsById(id));
    }
}
