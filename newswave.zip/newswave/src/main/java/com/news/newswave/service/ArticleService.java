package com.news.newswave.service;

import com.news.newswave.model.Article;
import java.util.List;

public interface ArticleService {
    List<Article> getAllArticles();
    Article getArticleById(Long id);
}
