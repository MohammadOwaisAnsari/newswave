package com.news.newswave.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.news.newswave.model.NewsArticle;
import com.news.newswave.repository.NewsRepository;

@Service
public class NewsServiceImpl implements NewsService {

    @Autowired
    private NewsRepository newsRepository;

    @Override
    public List<NewsArticle> getTrendingNews() {
        // Example implementation for trending news
        return newsRepository.findTrendingNews();
    }

    @Override
    public List<NewsArticle> getNewsByCategory(Long categoryId) {
        return newsRepository.findByCategoryId(categoryId);
    }

    @Override
    public NewsArticle getNewsById(Long id) {
        return newsRepository.findById(id).orElse(null);
    }
}
