package com.news.newswave.service;

import com.news.newswave.model.User;

public interface UserService {
    User getUserById(Long id);
    User updateUser(Long id, User user);
}
