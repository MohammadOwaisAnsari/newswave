package com.news.newswave.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class ViewController {

    @GetMapping("/")
    public String homePage() {
        return "index";  // Corresponds to src/main/resources/templates/index.html
    }

    @GetMapping("/article")
    public String articlePage() {
        return "article";  // Corresponds to src/main/resources/templates/article.html
    }

    @GetMapping("/category")
    public String categoryPage() {
        return "category";  // Corresponds to src/main/resources/templates/category.html
    }

    @GetMapping("/profile")
    public String profilePage() {
        return "profile";  // Corresponds to src/main/resources/templates/profile.html
    }

    @GetMapping("/search")
    public String searchPage() {
        return "search";  // Corresponds to src/main/resources/templates/search.html
    }
}
