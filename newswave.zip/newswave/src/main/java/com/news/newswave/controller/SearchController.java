package com.news.newswave.controller;

import com.news.newswave.model.NewsArticle;
import com.news.newswave.service.SearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/search")
public class SearchController {

    @Autowired
    private SearchService searchService;

    @GetMapping
    public ResponseEntity<List<NewsArticle>> searchNews(@RequestParam String query) {
        return ResponseEntity.ok(searchService.searchNews(query));
    }
}
