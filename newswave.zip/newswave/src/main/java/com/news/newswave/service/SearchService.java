package com.news.newswave.service;

import com.news.newswave.model.NewsArticle;
import java.util.List;

public interface SearchService {
    List<NewsArticle> searchNews(String query);
}
