package com.news.newswave.service;

import com.news.newswave.model.User;
import com.news.newswave.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public User getUserById(Long id) {
        return userRepository.findById(id).orElse(null);
    }

    @Override
    public User updateUser(Long id, User user) {
        // Assuming that user with the same ID exists
        user.setId(id);
        return userRepository.save(user);
    }
}




